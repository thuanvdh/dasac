 <!-- Footer -->
 <hr>
<footer>
    <div class="row">
        <div class="col-md-12">
            <p>Copyright &copy; Your Website 2020</p>
        </div>
    </div>
</footer>

 <!-- end Footer -->